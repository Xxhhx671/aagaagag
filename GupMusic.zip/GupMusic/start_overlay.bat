@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" "C:\Users\user\node_modules\electron\dist\electron.exe" "%~dp0overlay"
