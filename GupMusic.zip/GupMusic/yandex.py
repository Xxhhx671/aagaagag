# -*- coding: utf-8 -*-
"""Yandex Music API helper used by GUP MUSIC.

The OAuth token is read from the running YandexMusicMod app profile and is
only ever sent to api.music.yandex.net.
"""
import json
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request

API = 'https://api.music.yandex.net'
PROFILE = os.path.join(os.environ.get('APPDATA', ''), 'YandexMusicMod')

HEADERS = {
    'Authorization': 'OAuth {token}',
    'X-Yandex-Music-Client': 'YandexMusicDesktopAppWindows/5.86.0',
    'X-Yandex-Music-Frontend': 'new',
    'X-Yandex-Music-Without-Invocation-Info': '1',
    'User-Agent': 'Mozilla/5.0',
}


def profile_files(subdir):
    base = os.path.join(PROFILE, subdir)
    if not os.path.isdir(base):
        return []
    tmp = tempfile.mkdtemp(prefix='gupmusic_')
    paths = []
    for root, _, files in os.walk(base):
        for name in files:
            try:
                dst = os.path.join(tmp, str(len(paths)) + '_' + name)
                shutil.copy2(os.path.join(root, name), dst)
                paths.append(dst)
            except OSError:
                pass
    return paths


def find_token():
    for path in profile_files(os.path.join('Local Storage', 'leveldb')):
        data = open(path, 'rb').read().decode('utf-8', 'ignore')
        m = re.search(r'y0__[A-Za-z0-9_\-]{30,}', data)
        if m:
            return m.group()
    return None


def request(path, token=None, method='GET', body=None, params=None):
    token = token or find_token()
    if not token:
        return None
    headers = {k: v.format(token=token) for k, v in HEADERS.items()}
    if body is not None:
        headers['Content-Type'] = 'application/json'
        body = json.dumps(body).encode('utf-8')
    url = API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except (urllib.error.HTTPError, OSError, ValueError):
        return None


def unwrap(data):
    if isinstance(data, dict) and 'result' in data:
        return data['result']
    return data


def norm(t, liked=None):
    """Normalize a raw Yandex track object for the player."""
    if not t:
        return None
    cover = t.get('coverUri') or (t.get('cover') or {}).get('uri', '')
    albums = t.get('albums') or ([t['album']] if t.get('album') else [])
    album = albums[0] if albums else {}
    entry = {
        'id': str(t.get('id', '')),
        'title': t.get('title', ''),
        'version': t.get('version', ''),
        'artists': ', '.join(a.get('name', '') for a in (t.get('artists') or [])),
        'album': album.get('title', ''),
        'year': album.get('year', 0),
        'durationMs': t.get('durationMs', 0),
        'cover': 'https://' + cover.replace('%%', '400x400') if cover else '',
        'explicit': bool(t.get('explicit') or t.get('contentWarning') == 'explicit'),
        'liked': t.get('liked') if liked is None else liked,
    }
    return entry


def resolve(ids, token=None):
    """Fetch full metadata for a list of track ids (in order, deduped)."""
    ids = [str(i) for i in ids]
    seen, unique = set(), []
    for i in ids:
        if i and i not in seen:
            seen.add(i)
            unique.append(i)
    out = []
    for i in range(0, len(unique), 40):
        data = request('/tracks?trackIds=' + ','.join(unique[i:i + 40]), token)
        res = unwrap(data)
        if isinstance(res, dict):
            res = res.get('tracks', [])
        if isinstance(res, list):
            out.extend(res)
    return [norm(t) for t in out if t]


def account(token=None):
    data = request('/account/status', token)
    res = unwrap(data) or {}
    acc = res.get('account') or {}
    return {
        'uid': acc.get('uid', 0),
        'name': acc.get('displayName') or acc.get('login') or '',
        'login': acc.get('login', ''),
        'hasPlus': bool((res.get('permissions') or {}).get('values')),
    }


def active_queue():
    """Track ids cached in the running Yandex Music desktop app."""
    ids, seen = [], set()
    files = profile_files('IndexedDB')
    files.sort(key=lambda p: (0 if 'music-application_desktop' in p else 1, p))
    for path in files:
        if os.path.getsize(path) > 12 * 1024 * 1024:
            continue
        data = open(path, 'rb').read()
        for m in re.finditer(rb'(?<![0-9])1[0-9]{8}(?![0-9])', data):
            tid = m.group().decode()
            if tid not in seen:
                seen.add(tid)
                ids.append(tid)
    return ids


def wave(token=None):
    data = request('/rotor/session/new', token, method='POST', body={
        'seeds': ['user:onyourwave'],
        'includeTracksInResponse': True,
        'includeWaveModel': True,
        'allowExplicit': True,
    })
    res = unwrap(data) or {}
    tracks = []
    for item in res.get('sequence') or []:
        t = norm(item.get('track'), liked=bool(item.get('liked')))
        if t:
            tracks.append(t)
    return tracks, res.get('radioSessionId', '')


def wave_more(session_id, queue_ids, token=None):
    data = request(f'/rotor/session/{session_id}/tracks', token, method='POST', body={
        'queue': [str(i) for i in queue_ids], 'feedbacks': [],
    })
    res = unwrap(data) or {}
    tracks = []
    for item in res.get('sequence') or []:
        t = norm(item.get('track'), liked=bool(item.get('liked')))
        if t:
            tracks.append(t)
    return tracks


def liked_tracks(token=None, acc=None):
    acc = acc or account(token)
    uid = acc['uid']
    data = request(f'/users/{uid}/playlists/3?richTracks=true', token)
    res = unwrap(data) or {}
    tracks = []
    for item in res.get('tracks') or []:
        t = item.get('track') if isinstance(item, dict) else item
        entry = norm(t, liked=True)
        if entry:
            tracks.append(entry)
    if tracks:
        return tracks
    # fallback: short ids + resolve
    lib = request(f'/users/{uid}/likes/tracks?page=0&pageSize=200', token) or {}
    ids = [x.get('id') for x in ((lib.get('library') or {}).get('tracks') or [])]
    return [dict(t, liked=True) for t in resolve(ids, token)]


def cover_url(item):
    uri = item.get('coverUri') or (item.get('cover') or {}).get('uri', '')
    return 'https://' + uri.replace('%%', '400x400') if uri else ''


def playlists(token=None, acc=None):
    acc = acc or account(token)
    uid = acc['uid']
    liked = unwrap(request(f'/users/{uid}/playlists/3', token)) or {}
    out = [{
        'uid': uid, 'kind': 3, 'title': 'Мне нравится',
        'cover': cover_url(liked), 'tracksCount': liked.get('trackCount', 0), 'special': True,
    }]
    feed = unwrap(request('/feed', token)) or {}
    for block in feed.get('generatedPlaylists') or []:
        p = block.get('data') or {}
        if not p.get('title') or not p.get('uid'):
            continue
        out.append({
            'uid': p.get('uid'), 'kind': p.get('kind'), 'title': p.get('title'),
            'cover': cover_url(p), 'tracksCount': p.get('trackCount', 0), 'special': False,
        })
    own = unwrap(request(f'/users/{uid}/playlists/list', token)) or []
    for p in own:
        out.append({
            'uid': p.get('uid', uid), 'kind': p.get('kind'), 'title': p.get('title', ''),
            'cover': cover_url(p), 'tracksCount': p.get('trackCount', 0), 'special': False,
        })
    return out


def playlist_tracks(uid, kind, token=None):
    data = request(f'/users/{uid}/playlists/{kind}?richTracks=true', token)
    res = unwrap(data) or {}
    tracks = []
    for item in res.get('tracks') or []:
        t = item.get('track') if isinstance(item, dict) else item
        entry = norm(t)
        if entry:
            tracks.append(entry)
    return tracks


def search(q, token=None):
    data = request('/search', token, params={
        'text': q, 'page': 0, 'type': 'track', 'nocorrect': 'true', 'limit': 40,
    })
    res = unwrap(data) or {}
    results = (res.get('tracks') or {}).get('results') or []
    return [norm(t) for t in results if t]


def set_like(track_id, on, token=None, acc=None):
    acc = acc or account(token)
    uid = acc['uid']
    if on:
        return request(f'/users/{uid}/likes/tracks/add?track-id={track_id}', token, method='POST') is not None
    return request(f'/users/{uid}/likes/tracks/{track_id}/remove', token, method='POST') is not None
