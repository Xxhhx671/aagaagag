# -*- coding: utf-8 -*-
"""Local server for GUP MUSIC — full Yandex Music experience."""
import json
import os
import sys
import urllib.error
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

import sync
import yandex

ROOT = os.path.dirname(os.path.abspath(__file__))

# Shared state between the web player and the always-on-top overlay window.
OVERLAY_STATE = {
    'hasTrack': False, 'playing': False,
    'title': '', 'artist': '', 'cover': '',
    'time': 0, 'duration': 0, 'shuffle': False, 'repeat': False, 'volume': 75,
}
OVERLAY_COMMANDS = []


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, fmt, *args):
        if '/api/' in (self.path or ''):
            super().log_message(fmt, *args)

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parts = urlsplit(self.path)
        path = parts.path
        q = parse_qs(parts.query)
        one = lambda k, d='': (q.get(k) or [d])[0]

        if path == '/api/tracks':
            try:
                with open(os.path.join(ROOT, 'tracks.json'), encoding='utf-8') as f:
                    return self._json(json.load(f))
            except (OSError, ValueError):
                res = sync.sync()
                if not res.get('ok'):
                    return self._json(res, 502)
                with open(os.path.join(ROOT, 'tracks.json'), encoding='utf-8') as f:
                    return self._json(json.load(f))

        if path == '/api/sync':
            return self._json(sync.sync())

        if path == '/api/me':
            return self._json(yandex.account())

        if path == '/api/wave':
            tracks, session = yandex.wave()
            return self._json({'tracks': tracks, 'session': session})

        if path == '/api/wave/more':
            session = one('session', '')
            ids = [x for x in one('queue', '').split(',') if x]
            if not session or not ids:
                return self._json({'tracks': []})
            return self._json({'tracks': yandex.wave_more(session, ids)})

        if path == '/api/liked':
            return self._json({'tracks': yandex.liked_tracks()})

        if path == '/api/playlists':
            return self._json({'playlists': yandex.playlists()})

        if path == '/api/playlist':
            try:
                uid, kind = int(one('uid', '0')), int(one('kind', '0'))
            except ValueError:
                return self._json({'error': 'bad uid/kind'}, 400)
            return self._json({'tracks': yandex.playlist_tracks(uid, kind)})

        if path == '/api/search':
            query = one('q', '').strip()
            if not query:
                return self._json({'tracks': []})
            return self._json({'tracks': yandex.search(query)})

        if path == '/api/like':
            tid = one('id', '')
            on = one('on', '1') == '1'
            if not tid:
                return self._json({'error': 'no id'}, 400)
            return self._json({'ok': yandex.set_like(tid, on)})

        if path == '/api/overlay/state':
            return self._json(OVERLAY_STATE)

        if path == '/api/overlay/command':
            commands = list(OVERLAY_COMMANDS)
            OVERLAY_COMMANDS.clear()
            return self._json({'commands': commands})

        if path.startswith('/api/stream/'):
            return self.stream(unquote(path[len('/api/stream/'):]))

        super().do_GET()

    def do_POST(self):
        parts = urlsplit(self.path)
        path = parts.path
        if path not in ('/api/overlay/state', '/api/overlay/command'):
            self.send_error(404)
            return
        try:
            size = int(self.headers.get('Content-Length', 0))
            data = json.loads(self.rfile.read(size).decode('utf-8')) if size else {}
        except (ValueError, OSError):
            data = {}
        if path == '/api/overlay/state':
            for key in OVERLAY_STATE:
                if key in data:
                    OVERLAY_STATE[key] = data[key]
            return self._json({'ok': True})
        if isinstance(data, dict) and data.get('action'):
            OVERLAY_COMMANDS.append(data)
        return self._json({'ok': True})

    def stream(self, track_id):
        """Proxy a real MP3 stream from Yandex CDN (direct link, Range aware)."""
        token = yandex.find_token()
        if not token:
            return self._json({'error': 'no token'}, 502)
        try:
            info = yandex.request('/tracks/' + track_id + '/download-info?direct=true', token)
            res = yandex.unwrap(info) or []
            if isinstance(res, dict):
                res = res.get('tracks', [])
            if not res:
                raise ValueError('no direct stream')
            media = res[0].get('downloadInfoUrl') or res[0].get('url')
            if not media:
                raise ValueError('no stream url')

            headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://music.yandex.ru/'}
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng
            req = urllib.request.Request(media, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
                self.send_response(resp.status)
                self.send_header('Content-Type', 'audio/mpeg')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-Length', str(len(data)))
                cr = resp.headers.get('Content-Range')
                if cr:
                    self.send_header('Content-Range', cr)
                self.end_headers()
                self.wfile.write(data)
        except Exception as e:
            self._json({'error': str(e)}, 502)


if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    print(f'GUP MUSIC -> http://localhost:{port}')
    ThreadingHTTPServer(('127.0.0.1', port), Handler).serve_forever()
