/* Always-on-top island: mirrors player state and sends commands to the web app. */
const { ipcRenderer } = require('electron');
const API = 'http://127.0.0.1:8080';
const $ = (id) => document.getElementById(id);

const island = $('island');
const cover = $('isCover');
let lastCover = '';

const fmt = (ms) => {
  if (!isFinite(ms) || ms < 0) ms = 0;
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

async function command(action, value) {
  try {
    await fetch(API + '/api/overlay/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, value }),
    });
  } catch (_) { /* server not running */ }
}

async function poll() {
  try {
    const r = await fetch(API + '/api/overlay/state');
    const s = await r.json();
    island.classList.toggle('is-visible', !!s.hasTrack);
    document.body.classList.toggle('is-playing', !!s.playing);
    if (s.cover && s.cover !== lastCover) { cover.src = s.cover; lastCover = s.cover; }
    $('isTitle').textContent = s.title || '—';
    $('isArtist').textContent = s.artist || '—';
    $('isCur').textContent = fmt(s.time);
    $('isDur').textContent = fmt(s.duration);
    $('isFill').style.width = `${Math.min(100, (s.time / (s.duration || 1)) * 100)}%`;
    $('isShuffle').classList.toggle('is-on', !!s.shuffle);
    $('isRepeat').classList.toggle('is-on', !!s.repeat);
  } catch (_) {
    island.classList.remove('is-visible');
  }
}

$('isPlay').addEventListener('click', () => command('toggle'));
$('isPrev').addEventListener('click', () => command('prev'));
$('isNext').addEventListener('click', () => command('next'));
$('isBack').addEventListener('click', () => command('skip', -10000));
$('isFwd').addEventListener('click', () => command('skip', 10000));
$('isShuffle').addEventListener('click', () => command('shuffle'));
$('isRepeat').addEventListener('click', () => command('repeat'));
$('isStop').addEventListener('click', () => command('stop'));
$('isClose').addEventListener('click', () => ipcRenderer.send('hide-island'));

$('isSeek').addEventListener('pointerdown', (e) => {
  const rect = e.currentTarget.getBoundingClientRect();
  command('seek', Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)));
});

island.addEventListener('pointermove', (e) => {
  const r = island.getBoundingClientRect();
  island.style.setProperty('--mx', `${e.clientX - r.left}px`);
  island.style.setProperty('--my', `${e.clientY - r.top}px`);
});

poll();
setInterval(poll, 350);
