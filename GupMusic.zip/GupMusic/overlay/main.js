const { app, BrowserWindow, globalShortcut, screen, ipcMain } = require('electron');
const path = require('path');

let win = null;

function createWindow() {
  const area = screen.getPrimaryDisplay().workAreaSize;
  win = new BrowserWindow({
    width: 330,
    height: 196,
    x: 92,
    y: Math.max(80, area.height - 196 - 108),
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    focusable: true,
    hasShadow: false,
    webPreferences: { nodeIntegration: true, contextIsolation: false },
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  win.on('closed', () => { win = null; });
}

ipcMain.on('hide-island', () => { if (win) win.hide(); });

app.whenReady().then(() => {
  createWindow();
  globalShortcut.register('Control+Alt+G', () => {
    if (win && win.isVisible()) win.hide();
    else if (win) win.show();
    else createWindow();
  });
});

app.on('window-all-closed', (e) => e.preventDefault());
