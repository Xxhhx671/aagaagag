/* ================= GUP — application logic ================= */
(() => {
  const $ = (id) => document.getElementById(id);
  const $q = (sel, root = document) => root.querySelector(sel);

  const el = {
    content: $('content'), nav: document.querySelectorAll('.rail-btn[data-view]'),
    search: $('searchInput'), account: $('accountBadge'), chips: $('sidePlaylists'),
    sync: $('syncBtn'), status: $('sideStatus'),
    pbCover: $('pbCover'), pbTitle: $('pbTitle'), pbArtist: $('pbArtist'), pbLike: $('pbLike'),
    play: $('playBtn'), prev: $('prevBtn'), next: $('nextBtn'),
    shuffle: $('shuffleBtn'), repeat: $('repeatBtn'), mute: $('muteBtn'), vol: $('volume'),
    cur: $('curTime'), dur: $('durTime'), seek: $('progressTrack'), fill: $('progressFill'),
    viz: $('viz'), scene: $('immersive'), sceneBg: $('immersiveBg'),
    bigCover: $('bigCover'), bigTitle: $('bigTitle'), bigArtist: $('bigArtist'), bigAlbum: $('bigAlbum'),
    bigSeek: $('bigProgressTrack'), bigFill: $('bigProgressFill'), bigCur: $('bigCurTime'), bigDur: $('bigDurTime'),
    bigPlay: $('bigPlay'), bigPrev: $('bigPrev'), bigNext: $('bigNext'),
    bigShuffle: $('bigShuffle'), bigRepeat: $('bigRepeat'),
    closeScene: $('closeImmersive'), expand: $('expandBtn'),
    mode: $('modeLabel'), toast: $('toast'), bgA: $('bgA'), bgB: $('bgB'),
    island: $('island'), isCover: $('isCover'), isTitle: $('isTitle'), isArtist: $('isArtist'),
    isClose: $('isClose'), isSeek: $('isSeek'), isFill: $('isFill'), isCur: $('isCur'), isDur: $('isDur'),
    isPlay: $('isPlay'), isPrev: $('isPrev'), isNext: $('isNext'), isShuffle: $('isShuffle'),
    isRepeat: $('isRepeat'), isStop: $('isStop'), isBack: $('isBack'), isFwd: $('isFwd'),
  };

  const S = {
    view: 'wave', tracks: [], order: [], pos: 0, playing: false, visual: true,
    shuffle: false, repeat: false, time: 0, last: 0, seeking: false,
    audio: new Audio(), ctx: null, analyser: null, data: null,
    liked: new Set(), session: '', waveQueue: [], viewTracks: [], playlists: [], me: null,
    bgToggle: false, lastVol: 75,
  };

  const fmt = (ms) => {
    if (!isFinite(ms) || ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function toast(text) {
    el.toast.textContent = text;
    el.toast.classList.add('is-show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.toast.classList.remove('is-show'), 2500);
  }

  async function api(path) {
    try {
      const r = await fetch(path);
      if (!r.ok) throw 0;
      return await r.json();
    } catch (_) {
      toast('Нет связи с Яндекс Музыкой');
      return null;
    }
  }

  /* ---------- boot ---------- */
  async function init() {
    S.me = await api('/api/me');
    if (S.me && S.me.name) {
      el.account.textContent = S.me.name;
      el.status.textContent = (S.me.name[0] || 'G').toUpperCase();
    }
    const pl = await api('/api/playlists');
    S.playlists = (pl && pl.playlists) || [];
    renderChips();

    el.sync.addEventListener('click', async () => {
      el.sync.classList.add('is-spin');
      const r = await api('/api/sync');
      el.sync.classList.remove('is-spin');
      if (r && r.ok) {
        toast(`Обновлено: ${r.count} треков`);
        if (S.view === 'queue') loadView('queue');
      } else toast('Не удалось обновить');
    });

    bindUI();
    loadView('wave');
  }

  function renderChips() {
    el.chips.innerHTML = S.playlists.slice(0, 4).map((p, i) => `
      <button class="rail__chip" data-i="${i}" title="${esc(p.title)}">${i === 0
        ? '<svg viewBox="0 0 24 24" fill="none"><path d="M12 20s-7.2-4.5-9-9a4.7 4.7 0 0 1 9-2.4A4.7 4.7 0 0 1 21 11c-1.8 4.5-9 9-9 9Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'
        : '<svg viewBox="0 0 24 24" fill="none"><path d="M9 18V5l11-2v13" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6" cy="18" r="3" fill="currentColor"/><circle cx="17" cy="16" r="3" fill="currentColor"/></svg>'}</button>`).join('');
    el.chips.querySelectorAll('.rail__chip').forEach((b) => b.addEventListener('click', () => {
      const p = S.playlists[Number(b.dataset.i)];
      p && (p.uid && p.kind && !p.special ? loadView('playlist', p) : loadView('liked'));
    }));
  }

  /* ---------- views ---------- */
  async function loadView(view, opts = {}) {
    S.view = view;
    el.nav.forEach((b) => b.classList.toggle('is-active', b.dataset.view === view));
    el.content.innerHTML = '<div class="content__loading">Загружаем музыку…</div>';
    el.content.classList.remove('view-in');

    if (view === 'wave') {
      const d = await api('/api/wave');
      if (!d) return;
      S.session = d.session || '';
      S.waveQueue = (d.tracks || []).map((t) => t.id);
      (d.tracks || []).forEach((t) => t.liked && S.liked.add(t.id));
      feature({
        eyebrow: 'ПЕРСОНАЛЬНО · ВОЛНА',
        title: 'Моя <em>волна</em>',
        desc: 'Поток, который подстраивается под ваш вкус. Включайте и просто слушайте — треки будут меняться сами.',
        art: '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="2.6" fill="currentColor"/><path d="M7.4 7.4a6.5 6.5 0 0 0 0 9.2M16.6 7.4a6.5 6.5 0 0 1 0 9.2M4.2 4.2a11 11 0 0 0 0 15.6M19.8 4.2a11 11 0 0 1 0 15.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',
        artWave: true,
        tracks: d.tracks || [],
        actions: [
          { label: 'Слушать', primary: true, fn: () => playTracks(S.viewTracks, 0) },
          { label: 'Новая волна', fn: () => loadView('wave') },
          { label: 'Ещё треков', fn: moreWave },
        ],
        figure: true,
      });
      return;
    }

    if (view === 'liked') {
      const d = await api('/api/liked');
      if (!d) return;
      d.tracks.forEach((t) => S.liked.add(t.id));
      feature({
        eyebrow: 'КОЛЛЕКЦИЯ', title: 'Мне <em>нравится</em>',
        desc: `${d.tracks.length} треков, которые вы сохранили.`,
        art: (d.tracks[0] || {}).cover || '',
        tracks: d.tracks,
        actions: [{ label: 'Слушать', primary: true, fn: () => playTracks(S.viewTracks, 0) }],
      });
      return;
    }

    if (view === 'queue') {
      const d = await api('/api/tracks');
      if (!d) return;
      feature({
        eyebrow: 'АКТИВНЫЙ ПРОЦЕСС', title: 'Из <em>приложения</em>',
        desc: `Очередь запущенного Яндекс Музыка · ${d.account || ''}. Обновляется кнопкой слева.`,
        art: (d.tracks[0] || {}).cover || '',
        tracks: d.tracks,
        actions: [{ label: 'Слушать', primary: true, fn: () => playTracks(S.viewTracks, 0) }],
      });
      return;
    }

    if (view === 'playlists') {
      el.content.innerHTML = `
        <div class="sec-head"><h2>Плейлисты</h2><span>${S.playlists.length} подборок</span></div>
        <div class="shelf" id="shelf"></div>`;
      const shelf = $('shelf');
      shelf.innerHTML = S.playlists.map((p, i) => `
        <button class="pl" data-i="${i}" style="animation-delay:${i * 45}ms">
          <div class="pl__art">${p.cover ? `<img src="${esc(p.cover)}" alt="" loading="lazy">` : `<span>${i === 0
            ? '<svg viewBox="0 0 24 24" fill="none"><path d="M12 20s-7.2-4.5-9-9a4.7 4.7 0 0 1 9-2.4A4.7 4.7 0 0 1 21 11c-1.8 4.5-9 9-9 9Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>'
            : '<svg viewBox="0 0 24 24" fill="none"><path d="M9 18V5l11-2v13" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6" cy="18" r="3" fill="currentColor"/><circle cx="17" cy="16" r="3" fill="currentColor"/></svg>'}</span>`}
            <div class="pl__play"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8.5 5.5v13l11-6.5z"/></svg></div>
          </div>
          <div class="pl__title">${esc(p.title)}</div>
          <div class="pl__sub">${p.tracksCount ? p.tracksCount + ' треков' : (i === 0 ? 'ваши треки' : 'подборка')}</div>
        </button>`).join('');
      shelf.querySelectorAll('.pl').forEach((b) => b.addEventListener('click', () => {
        const p = S.playlists[Number(b.dataset.i)];
        p && (p.uid && p.kind && !p.special ? loadView('playlist', p) : loadView('liked'));
      }));
      reveal();
      return;
    }

    if (view === 'playlist') {
      const d = await api(`/api/playlist?uid=${opts.uid}&kind=${opts.kind}`);
      if (!d) return;
      feature({
        eyebrow: 'ПЛЕЙЛИСТ', title: esc(opts.title || 'Плейлист'),
        desc: `${(d.tracks || []).length} треков`,
        art: opts.cover || (d.tracks[0] || {}).cover || '',
        tracks: d.tracks || [],
        actions: [{ label: 'Слушать', primary: true, fn: () => playTracks(S.viewTracks, 0) }],
      });
      return;
    }

    if (view === 'search') {
      const q = el.search.value.trim();
      if (!q) {
        el.content.innerHTML = `<div class="sec-head"><h2>Поиск</h2></div><div class="content__loading">Введите запрос и нажмите Enter</div>`;
        return;
      }
      const d = await api('/api/search?q=' + encodeURIComponent(q));
      if (!d) return;
      feature({
        eyebrow: 'РЕЗУЛЬТАТЫ', title: `«${esc(q)}»`,
        desc: `${d.tracks.length} треков в каталоге`,
        art: '',
        artWave: true,
        tracks: d.tracks,
        actions: [{ label: 'Слушать', primary: true, fn: () => playTracks(S.viewTracks, 0) }],
      });
    }
  }

  async function moreWave() {
    if (!S.session || !S.waveQueue.length) { toast('Сначала обновите волну'); return; }
    const r = await api(`/api/wave/more?session=${encodeURIComponent(S.session)}&queue=${encodeURIComponent(S.waveQueue.join(','))}`);
    if (!r || !r.tracks || !r.tracks.length) { toast('Волна обновится заново'); loadView('wave'); return; }
    S.viewTracks = S.viewTracks.concat(r.tracks);
    S.waveQueue = S.waveQueue.concat(r.tracks.map((t) => t.id));
    renderRows(S.viewTracks, $('list'));
    toast(`Добавлено ${r.tracks.length} треков`);
  }

  function reveal() {
    requestAnimationFrame(() => el.content.classList.add('view-in'));
  }

  function feature(cfg) {
    S.viewTracks = cfg.tracks || [];
    el.content.innerHTML = `
      <section class="feature">
        <div class="feature__art ${cfg.artWave ? 'feature__art--wave' : ''}">
          ${cfg.artWave ? cfg.art : (cfg.art ? `<img src="${esc(cfg.art)}" alt="">` : '<span><svg viewBox="0 0 24 24" fill="none"><path d="M9 18V5l11-2v13" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6" cy="18" r="3" fill="currentColor"/><circle cx="17" cy="16" r="3" fill="currentColor"/></svg></span>')}
        </div>
        <div class="feature__body">
          <div class="feature__eyebrow">${esc(cfg.eyebrow || '')}</div>
          <h1 class="feature__title">${cfg.title || ''}</h1>
          <p class="feature__desc">${esc(cfg.desc || '')}</p>
          <div class="feature__actions">
            ${(cfg.actions || []).map((a, i) => `<button class="${a.primary ? 'play-primary' : 'play-ghost'}" data-a="${i}">${a.primary ? '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8.5 5.5v13l11-6.5z"/></svg>' : ''}${a.label}</button>`).join('')}
          </div>
        </div>
        ${cfg.figure ? `<div class="feature__figure">${Array.from({ length: 28 }, (_, i) => `<i style="animation-delay:${(i * 47) % 900}ms;animation-duration:${900 + (i % 5) * 180}ms"></i>`).join('')}</div>` : ''}
      </section>
      <div class="sec-head"><h2>Треки</h2><span>${S.viewTracks.length}</span></div>
      <div class="list" id="list"></div>`;
    el.content.querySelectorAll('[data-a]').forEach((b) => b.addEventListener('click', () => (cfg.actions || [])[Number(b.dataset.a)].fn()));
    renderRows(S.viewTracks, $('list'));
    reveal();
  }

  function renderRows(tracks, box) {
    if (!box) return;
    const activeId = (current() || {}).id;
    box.innerHTML = tracks.map((t, i) => {
      const active = t.id === activeId;
      return `<div class="row ${active ? 'is-active' : ''} ${active && S.playing ? 'is-playing' : ''}" data-i="${i}">
        <span class="row__num">${i + 1}</span>
        <span class="row__eq"><i></i><i></i><i></i></span>
        <img class="row__art" src="${esc(t.cover)}" alt="" loading="lazy">
        <div>
          <div class="row__title">${esc(t.title)}${t.version ? `<small>${esc(t.version)}</small>` : ''}${t.explicit ? '<span class="explicit">E</span>' : ''}</div>
          <div class="row__artist">${esc(t.artists || 'Неизвестный исполнитель')}</div>
        </div>
        <div class="row__album">${esc(t.album || '')}</div>
        <div class="row__dur">${fmt(t.durationMs)}</div>
        <button class="row__like ${S.liked.has(t.id) ? 'is-on' : ''}" data-like="${esc(t.id)}" aria-label="Нравится">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 20s-7.2-4.5-9-9a4.7 4.7 0 0 1 9-2.4A4.7 4.7 0 0 1 21 11c-1.8 4.5-9 9-9 9Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
        </button>
      </div>`;
    }).join('');
    box.querySelectorAll('.row').forEach((row) => row.addEventListener('click', (e) => {
      if (e.target.closest('[data-like]')) return;
      const i = Number(row.dataset.i);
      const same = S.order.length === S.viewTracks.length && S.order.every((k, n) => S.tracks[k] && S.tracks[k].id === S.viewTracks[n].id);
      same ? select(i, true) : playTracks(S.viewTracks, i);
    }));
    box.querySelectorAll('[data-like]').forEach((b) => b.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleLike(b.dataset.like);
    }));
  }

  function refreshRows() {
    const box = $('list');
    if (box) renderRows(S.viewTracks, box);
    const t = current();
    el.pbLike.classList.toggle('is-on', !!t && S.liked.has(t.id));
  }

  async function toggleLike(id) {
    const on = !S.liked.has(id);
    on ? S.liked.add(id) : S.liked.delete(id);
    refreshRows();
    api(`/api/like?id=${encodeURIComponent(id)}&on=${on ? 1 : 0}`);
    toast(on ? 'В «Мне нравится»' : 'Удалено из избранного');
  }

  /* ---------- playback ---------- */
  const current = () => S.tracks[S.order[S.pos]];

  function playTracks(tracks, index = 0) {
    S.tracks = tracks.slice();
    S.order = tracks.map((_, i) => i);
    if (S.shuffle) {
      const first = S.order.splice(index, 1)[0];
      for (let i = S.order.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [S.order[i], S.order[j]] = [S.order[j], S.order[i]];
      }
      S.order.unshift(first);
      index = 0;
    }
    select(index, true);
  }

  function select(pos, autoplay = true) {
    if (!S.order.length) return;
    S.pos = (pos + S.order.length) % S.order.length;
    const t = current();
    if (!t) return;

    S.time = 0;
    S.last = performance.now();
    el.pbCover.src = t.cover;
    el.bigCover.src = t.cover;
    el.isCover.src = t.cover;
    el.pbTitle.textContent = t.title;
    el.pbArtist.textContent = t.artists || '—';
    el.bigTitle.textContent = t.title;
    el.bigArtist.textContent = t.artists || '—';
    el.bigAlbum.textContent = [t.album, t.year].filter(Boolean).join(' · ');
    el.isTitle.textContent = t.title;
    el.isArtist.textContent = t.artists || '—';
    el.dur.textContent = fmt(t.durationMs);
    el.bigDur.textContent = fmt(t.durationMs);
    el.isDur.textContent = fmt(t.durationMs);
    el.cur.textContent = '0:00';
    el.bigCur.textContent = '0:00';
    el.isCur.textContent = '0:00';
    [el.fill, el.bigFill, el.isFill].forEach((f) => (f.style.width = '0%'));
    document.body.classList.add('has-track');
    el.island.classList.remove('is-hidden');
    el.sceneBg.style.backgroundImage = `url("${t.cover}")`;
    const bg = S.bgToggle ? el.bgA : el.bgB;
    const old = S.bgToggle ? el.bgB : el.bgA;
    bg.style.backgroundImage = `url("${t.cover}")`;
    bg.classList.add('is-active');
    old.classList.remove('is-active');
    S.bgToggle = !S.bgToggle;
    el.mode.textContent = 'ПОДКЛЮЧЕНИЕ К ПОТОКУ';

    S.audio.pause();
    S.audio.src = '/api/stream/' + encodeURIComponent(t.id);
    S.audio.volume = el.vol.value / 100;
    S.visual = true;
    let settled = false;
    const fallback = () => {
      if (settled) return;
      settled = true;
      S.visual = true;
      el.mode.textContent = 'ВИЗУАЛЬНЫЙ РЕЖИМ';
    };
    S.audio.onerror = fallback;
    S.audio.onplaying = () => {
      if (settled) return;
      settled = true;
      S.visual = false;
      el.mode.textContent = 'ЖИВОЙ ПОТОК · 320 KBPS';
      setupAnalyser();
    };
    S.audio.ontimeupdate = () => { if (!S.visual) S.time = S.audio.currentTime * 1000; };
    S.audio.onended = () => { if (!S.visual && S.playing) next(true); };
    setTimeout(() => { if (S.audio.readyState < 2) fallback(); }, 5000);

    refreshRows();
    if (autoplay) play();
  }

  function setupAnalyser() {
    try {
      if (!S.ctx) {
        S.ctx = new (window.AudioContext || window.webkitAudioContext)();
        S.analyser = S.ctx.createAnalyser();
        S.analyser.fftSize = 128;
        S.analyser.smoothingTimeConstant = .82;
        const src = S.ctx.createMediaElementSource(S.audio);
        src.connect(S.analyser);
        S.analyser.connect(S.ctx.destination);
        S.data = new Uint8Array(S.analyser.frequencyBinCount);
      }
      S.ctx.resume();
    } catch (_) { /* sound still works */ }
  }

  function play() {
    if (!current()) return;
    S.playing = true;
    S.last = performance.now();
    document.body.classList.add('is-playing');
    el.play.title = 'Пауза';
    el.bigPlay.title = 'Пауза';
    S.audio.play().catch(() => {});
    refreshRows();
  }
  function pause() {
    S.playing = false;
    document.body.classList.remove('is-playing');
    el.play.title = 'Воспроизвести';
    el.bigPlay.title = 'Воспроизвести';
    S.audio.pause();
    refreshRows();
  }
  const toggle = () => S.playing ? pause() : play();

  function next(auto = false) {
    if (S.pos === S.order.length - 1 && !S.shuffle && !S.repeat && auto) { pause(); S.time = 0; return; }
    select(S.pos + 1, S.playing || auto);
  }
  function prev() {
    if (S.time > 4000) { S.time = 0; if (!S.visual) S.audio.currentTime = 0; return; }
    select(S.pos - 1, S.playing);
  }
  function toggleShuffle() {
    S.shuffle = !S.shuffle;
    [el.shuffle, el.bigShuffle, el.isShuffle].forEach((b) => b.classList.toggle('is-on', S.shuffle));
    toast(S.shuffle ? 'Перемешивание' : 'По порядку');
  }
  function toggleRepeat() {
    S.repeat = !S.repeat;
    [el.repeat, el.bigRepeat, el.isRepeat].forEach((b) => b.classList.toggle('is-on', S.repeat));
    toast(S.repeat ? 'Повтор включён' : 'Повтор выключен');
  }

  function stop() {
    pause();
    S.time = 0;
    if (S.audio.readyState) S.audio.currentTime = 0;
    [el.fill, el.bigFill, el.isFill].forEach((f) => (f.style.width = '0%'));
    [el.cur, el.bigCur, el.isCur].forEach((c) => (c.textContent = '0:00'));
    toast('Остановлено');
  }

  function skip(seconds) {
    const t = current();
    if (!t) return;
    const target = Math.min(t.durationMs, Math.max(0, S.time + seconds * 1000));
    S.time = target;
    if (!S.visual) S.audio.currentTime = target / 1000;
    const ratio = target / t.durationMs;
    [el.fill, el.bigFill, el.isFill].forEach((f) => (f.style.width = `${ratio * 100}%`));
  }

  function bindSeek(track) {
    const seekTo = (e) => {
      const r = track.getBoundingClientRect();
      const ratio = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      const t = current();
      if (!t) return;
      S.time = ratio * t.durationMs;
      if (!S.visual) S.audio.currentTime = S.time / 1000;
      [el.fill, el.bigFill].forEach((f) => (f.style.width = `${ratio * 100}%`));
    };
    track.addEventListener('pointerdown', (e) => { S.seeking = true; track.setPointerCapture(e.pointerId); seekTo(e); });
    track.addEventListener('pointermove', (e) => { if (S.seeking) seekTo(e); });
    track.addEventListener('pointerup', () => { S.seeking = false; });
  }

  /* ---------- always-on-top overlay bridge ---------- */
  let lastPush = 0;
  function pushState() {
    const now = performance.now();
    if (now - lastPush < 200) return;
    lastPush = now;
    const t = current() || {};
    fetch('/api/overlay/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hasTrack: !!t.id,
        playing: S.playing,
        title: t.title || '',
        artist: t.artists || '',
        cover: t.cover || '',
        time: S.time,
        duration: t.durationMs || 0,
        shuffle: S.shuffle,
        repeat: S.repeat,
        volume: Number(el.vol.value),
      }),
    }).catch(() => {});
  }

  async function pollCommands() {
    try {
      const r = await fetch('/api/overlay/command');
      const d = await r.json();
      const commands = d.commands || [];
      commands.forEach((c) => {
        switch (c.action) {
          case 'toggle': toggle(); break;
          case 'next': next(); break;
          case 'prev': prev(); break;
          case 'stop': stop(); break;
          case 'shuffle': toggleShuffle(); break;
          case 'repeat': toggleRepeat(); break;
          case 'skip': skip(Number(c.value || 0)); break;
          case 'seek': {
            const t = current();
            if (t) {
              S.time = Number(c.value) * t.durationMs;
              if (!S.visual) S.audio.currentTime = S.time / 1000;
            }
            break;
          }
          case 'volume':
            el.vol.value = c.value;
            el.vol.dispatchEvent(new Event('input'));
            break;
        }
      });
      if (commands.length) pushState();
    } catch (_) { /* server unavailable */ }
  }
  setInterval(pollCommands, 250);

  /* ---------- visualizer ---------- */
  const bars = [];
  for (let i = 0; i < 30; i++) {
    const b = document.createElement('i');
    el.viz.appendChild(b);
    bars.push(b);
  }
  function loop(now) {
    const t = current();
    if (t) {
      if (S.playing && S.visual && !S.seeking) {
        S.time += now - S.last;
        if (S.time >= t.durationMs) next(true);
      }
      S.last = now;
      const ratio = Math.min(1, S.time / t.durationMs);
      if (!S.seeking) {
        el.fill.style.width = `${ratio * 100}%`;
        el.bigFill.style.width = `${ratio * 100}%`;
        el.isFill.style.width = `${ratio * 100}%`;
      }
      el.cur.textContent = fmt(S.time);
      el.bigCur.textContent = fmt(S.time);
      el.isCur.textContent = fmt(S.time);
    }

    let values = null;
    if (!S.visual && S.analyser && S.playing) {
      S.analyser.getByteFrequencyData(S.data);
      values = S.data;
    }
    const time = now / 1000;
    bars.forEach((b, i) => {
      let h;
      if (values) h = 3 + (values[Math.floor(i * values.length / bars.length)] / 255) * 19;
      else if (S.playing) {
        const a = Math.sin(time * 2.3 + i * .38) * .5 + .5;
        const c = Math.sin(time * 3.7 - i * .16) * .5 + .5;
        h = 3 + (a * .6 + c * .4) * 18 * (Math.sin((i / bars.length) * Math.PI) * .6 + .4);
      } else h = 3 + Math.sin(time * .8 + i * .25) * 1.2;
      b.style.height = `${Math.max(2, h)}px`;
    });
    pushState();
    requestAnimationFrame(loop);
  }

  /* ---------- UI ---------- */
  function bindUI() {
    el.nav.forEach((b) => b.addEventListener('click', () => loadView(b.dataset.view)));
    el.search.addEventListener('keydown', (e) => { if (e.key === 'Enter') loadView('search'); });
    el.play.addEventListener('click', toggle);
    el.bigPlay.addEventListener('click', toggle);
    el.next.addEventListener('click', () => next());
    el.bigNext.addEventListener('click', () => next());
    el.prev.addEventListener('click', prev);
    el.bigPrev.addEventListener('click', prev);
    el.shuffle.addEventListener('click', toggleShuffle);
    el.bigShuffle.addEventListener('click', toggleShuffle);
    el.repeat.addEventListener('click', toggleRepeat);
    el.bigRepeat.addEventListener('click', toggleRepeat);
    el.isPlay.addEventListener('click', toggle);
    el.isPrev.addEventListener('click', prev);
    el.isNext.addEventListener('click', () => next());
    el.isShuffle.addEventListener('click', toggleShuffle);
    el.isRepeat.addEventListener('click', toggleRepeat);
    el.isStop.addEventListener('click', stop);
    el.isBack.addEventListener('click', () => skip(-10));
    el.isFwd.addEventListener('click', () => skip(10));
    el.isClose.addEventListener('click', () => {
      el.island.classList.add('is-hidden');
      el.island.setAttribute('aria-hidden', 'true');
    });
    el.pbLike.addEventListener('click', () => { const t = current(); if (t) toggleLike(t.id); });
    el.vol.addEventListener('input', () => {
      S.audio.volume = el.vol.value / 100;
      if (Number(el.vol.value) > 0) S.lastVol = Number(el.vol.value);
    });
    el.mute.addEventListener('click', () => {
      el.vol.value = Number(el.vol.value) > 0 ? 0 : S.lastVol;
      el.vol.dispatchEvent(new Event('input'));
    });
    el.expand.addEventListener('click', () => {
      el.scene.classList.add('is-open');
      el.scene.setAttribute('aria-hidden', 'false');
    });
    el.closeScene.addEventListener('click', () => {
      el.scene.classList.remove('is-open');
      el.scene.setAttribute('aria-hidden', 'true');
    });
    const trackGlass = (e) => {
      const card = e.currentTarget.closest('.feature') || e.currentTarget;
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', `${e.clientX - r.left}px`);
      card.style.setProperty('--my', `${e.clientY - r.top}px`);
    };
    el.content.addEventListener('pointermove', trackGlass);
    el.scene.querySelector('.glass-hover').addEventListener('pointermove', trackGlass);
    el.island.addEventListener('pointermove', trackGlass);
    bindSeek(el.seek);
    bindSeek(el.bigSeek);
    bindSeek(el.isSeek);
    document.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); toggle(); }
      else if (e.code === 'ArrowRight') next();
      else if (e.code === 'ArrowLeft') prev();
      else if (e.code === 'KeyM') el.mute.click();
      else if (e.code === 'Escape') el.closeScene.click();
    });
  }

  init();
  requestAnimationFrame(loop);
})();
