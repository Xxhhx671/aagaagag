# -*- coding: utf-8 -*-
"""Sync the active queue from the running Yandex Music process into tracks.json."""
import datetime
import json
import os

import yandex

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tracks.json')


def sync():
    token = yandex.find_token()
    if not token:
        return {'ok': False, 'error': 'Яндекс Музыка не запущена — токен не найден'}

    ids = yandex.active_queue()
    if not ids:
        return {'ok': False, 'error': 'Очередь активного процесса не найдена'}

    tracks = yandex.resolve(ids, token)
    acc = yandex.account(token)
    payload = {
        'source': 'Яндекс Музыка · активный процесс',
        'account': acc['name'],
        'uid': acc['uid'],
        'syncedAt': datetime.datetime.now().isoformat(timespec='seconds'),
        'tracks': tracks,
    }
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return {'ok': True, 'count': len(tracks), 'account': acc['name']}


if __name__ == '__main__':
    print(json.dumps(sync(), ensure_ascii=False))
